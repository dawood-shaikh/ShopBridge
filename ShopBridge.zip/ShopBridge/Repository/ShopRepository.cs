﻿using Newtonsoft.Json;
using ShopBridge.Controllers;
using ShopBridge.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.UI.WebControls;

namespace ShopBridge.Repository
{
    public class ShopRepository : IShopRepository
    {
        private bool disposedValue;
        public string accessToken;
        public string Baseurl;
        public ShopRepository()
        {
            accessToken = ConfigurationManager.AppSettings["accessToken"];
            Baseurl = ConfigurationManager.AppSettings["BaseUrl"];
        }
        public void Addproduct(product prod,out ApiResponsedetails  apiResponsedetails)
        {
            ApiResponsedetails apiResponsedetails1 = new ApiResponsedetails();
            using (var client = new HttpClient())
            {
                var jsonString = JsonConvert.SerializeObject(prod);
                HttpContent httpContent = new StringContent(jsonString);
                httpContent.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + accessToken);
                client.BaseAddress = new Uri(Baseurl);
                HttpResponseMessage Res = Task.Run(() => client.PostAsync("api/Shop", httpContent)).Result;
                if (Res.IsSuccessStatusCode)
                {
                    var Response = Res.Content.ReadAsStringAsync().Result;
                    apiResponsedetails1.Status = "Success";
                    apiResponsedetails = apiResponsedetails1;
                }
                else //web api sent error response 
                {
                    apiResponsedetails1.Exception = Res.ReasonPhrase;
                    apiResponsedetails1.Status = "Failure";
                    apiResponsedetails = apiResponsedetails1;
                }
            }
        }

        public void Deleteproduct(int Id, out ApiResponsedetails apiResponsedetails)
        {
            using (var client = new HttpClient())
            {
                ApiResponsedetails apiResponsedetails1 = new ApiResponsedetails();
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + accessToken);
                client.BaseAddress = new Uri(Baseurl);
                HttpResponseMessage Res = Task.Run(() => client.DeleteAsync("api/Shop/"+Id)).Result;
                if (Res.IsSuccessStatusCode)
                {
                    var Response = Res.Content.ReadAsStringAsync().Result;
                    apiResponsedetails1.Status = "Success";
                    apiResponsedetails = apiResponsedetails1;
                }
                else //web api sent error response 
                {
                    apiResponsedetails1.Exception = Res.ReasonPhrase;
                    apiResponsedetails1.Status = "Failure";
                    apiResponsedetails = apiResponsedetails1;
                }
            }
        }

        public product GetProduct(int Id, out ApiResponsedetails apiResponsedetails)
        {
            product prod = null;

            using (var client = new HttpClient())
            {
                ApiResponsedetails apiResponsedetails1 = new ApiResponsedetails();
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + accessToken);
                HttpResponseMessage Res = Task.Run(() => client.GetAsync("api/Shop/"+Id)).Result;
                if (Res.IsSuccessStatusCode)
                {
                    var Response = Res.Content.ReadAsStringAsync().Result;
                    prod = JsonConvert.DeserializeObject<product>(Response);
                    apiResponsedetails1.Status = "Success";
                    apiResponsedetails = apiResponsedetails1;
                }
                else //web api sent error response 
                {
                    apiResponsedetails1.Exception = Res.ReasonPhrase;
                    apiResponsedetails1.Status = "Failure";
                    apiResponsedetails = apiResponsedetails1;
                }
                return prod;
            }
        }

        public  IEnumerable<product> GetProducts(out ApiResponsedetails apiResponsedetails)
        {
            IEnumerable<product> prod = null;

            using (var client = new HttpClient())
            {
                ApiResponsedetails apiResponsedetails1 = new ApiResponsedetails();
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + accessToken);
                
                HttpResponseMessage Res = Task.Run(() => client.GetAsync("api/Shop")).Result;
                if (Res.IsSuccessStatusCode)
                { 
                    var Response = Res.Content.ReadAsStringAsync().Result;
                    apiResponsedetails1.Status = "Success";
                    apiResponsedetails = apiResponsedetails1;
                    prod = JsonConvert.DeserializeObject<List<product>>(Response);
                }
                else //web api sent error response 
                {
                    apiResponsedetails1.Exception = Res.ReasonPhrase;
                    apiResponsedetails1.Status = "Failure";
                    apiResponsedetails = apiResponsedetails1;
                    prod = Enumerable.Empty<product>();
                }
                return prod;
            }
        }

        public void Updateproduct(product prod,out ApiResponsedetails apiResponsedetails)
        {
            using (var client = new HttpClient())
            {
                ApiResponsedetails apiResponsedetails1 = new ApiResponsedetails();
                var jsonString = JsonConvert.SerializeObject(prod);
                HttpContent httpContent = new StringContent(jsonString);
                httpContent.Headers.ContentType = new  MediaTypeWithQualityHeaderValue("application/json");
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + accessToken);
                client.BaseAddress = new Uri(Baseurl);
                HttpResponseMessage Res = Task.Run(() => client.PutAsync("api/Shop", httpContent)).Result;
                if (Res.IsSuccessStatusCode)
                {
                    var Response = Res.Content.ReadAsStringAsync().Result;
                    apiResponsedetails1.Status = "Success";
                    apiResponsedetails = apiResponsedetails1;
                }
                else //web api sent error response 
                {
                    apiResponsedetails1.Exception = Res.ReasonPhrase;
                    apiResponsedetails1.Status = "Failure";
                    apiResponsedetails = apiResponsedetails1;
                }
            }
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: dispose managed state (managed objects)
                }

                // TODO: free unmanaged resources (unmanaged objects) and override finalizer
                // TODO: set large fields to null
                disposedValue = true;
            }
        }

        // // TODO: override finalizer only if 'Dispose(bool disposing)' has code to free unmanaged resources
        // ~ShopRepository()
        // {
        //     // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
        //     Dispose(disposing: false);
        // }

        public void Dispose()
        {
            // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }
    }

}