﻿using ShopBridge.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopBridge.Repository
{
    public interface IShopRepository : IDisposable
    {
        IEnumerable<product> GetProducts(out ApiResponsedetails apiResponsedetails);
        product GetProduct(int Id, out ApiResponsedetails apiResponsedetails);
        void Updateproduct(product prod,out ApiResponsedetails apiResponsedetails);
        void Addproduct(product prod, out ApiResponsedetails apiResponsedetails);
        void Deleteproduct(int Id, out ApiResponsedetails apiResponsedetails);
    }
}
