﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ShopBridge.Models
{
    public class product
    {
        [Key]
        public int ProdId { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string Description { get; set; }
        [Required]
        [DisplayFormat(DataFormatString = "{0:C2}")]
        [Range(0.01, 100000, ErrorMessage = "Price is required between .01 and $100,000.")]
        [DataType(DataType.Currency, ErrorMessage = "Price should be in positive currency")]
        public decimal? Price { get; set; }
        public string imagepath { get; set; }
        public Nullable<System.DateTime> DOE { get; set; }
        public Nullable<bool> Active { get; set; }
    }
    public class ApiResponsedetails
    {
        private List<string> _validation = null;
        public ApiResponsedetails()
        {
            _validation = new List<string>();
        }
        public List<string> validation { get { return _validation; } set { _validation = value; } }
        public void AddValidation(string msg)
        {
            _validation.Add(msg);
            this._status = "Failure";
        }
        private string _status;
        public string Status
        {
            get { return _status; }
            set { _status = value; }
        }
        public string Exception { get; set; }
    }
}