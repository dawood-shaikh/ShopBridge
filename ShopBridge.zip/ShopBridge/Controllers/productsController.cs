﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ShopBridge.Models;
using ShopBridge.Repository;

namespace ShopBridge.Controllers
{
    public class productsController : Controller
    {
        private readonly IShopRepository _shopRepository = null;
        private ApiResponsedetails apiResponsedetails;
        public productsController(IShopRepository shopRepository)
        {
            _shopRepository = shopRepository;
        }

        // GET: products
        public ActionResult Index()
        {
            var data = _shopRepository.GetProducts(out  apiResponsedetails);
            if(apiResponsedetails.Status=="Failure")
            {
                ViewBag.Message = apiResponsedetails.Exception;
            }
            return View("Index",data);
        }

        // GET: products/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            product product = _shopRepository.GetProduct(id.Value, out apiResponsedetails);
            if (product == null)
            {
                return HttpNotFound();
            }
            return View(product);
        }

        // GET: products/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: products/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ProdId,Name,Description,Price,imagepath")] product product)
        {
            if (ModelState.IsValid)
            {
                _shopRepository.Addproduct(product , out  apiResponsedetails);
                if (apiResponsedetails.Status == "Failure")
                {
                    ViewBag.Message = apiResponsedetails.Exception;
                }
                else
                {
                    return RedirectToAction("Index");
                }
            }

            return View(product);
        }

        // GET: products/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            product product = _shopRepository.GetProduct(id.Value,out apiResponsedetails);
            if (apiResponsedetails.Status == "Failure")
            {
                ViewBag.Message = apiResponsedetails.Exception;
            }
            if (product == null)
            {
                return HttpNotFound();
            }
            return View(product);
        }

        // POST: products/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ProdId,Name,Description,Price,imagepath,DOE,Active")] product product)
        {
            if (ModelState.IsValid)
            {
                //db.Entry(product).State = EntityState.Modified;
                //db.SaveChanges();
                _shopRepository.Updateproduct(product,out  apiResponsedetails);
                if (apiResponsedetails.Status == "Failure")
                {
                    ViewBag.Message = apiResponsedetails.Exception;
                }
                return RedirectToAction("Index");
            }
            return View(product);
        }

        // GET: products/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            product product = _shopRepository.GetProduct(id.Value, out apiResponsedetails);
            if (apiResponsedetails.Status == "Failure")
            {
                ViewBag.Message = apiResponsedetails.Exception;
            }
            if (product == null)
            {
                return HttpNotFound();
            }
            return View(product);
        }

        // POST: products/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            _shopRepository.Deleteproduct(id.Value, out apiResponsedetails);
            if (apiResponsedetails.Status == "Failure")
            {
                ViewBag.Message = apiResponsedetails.Exception;
            }
            else
            {
                return RedirectToAction("Index");
            }
            return RedirectToAction("Delete/"+ id);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _shopRepository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
