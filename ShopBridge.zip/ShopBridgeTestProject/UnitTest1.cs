﻿using System;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ShopBridge.Controllers;
using ShopBridge.Models;
using ShopBridge.Repository;

namespace ShopBridgeTestProject
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestViewPositive()
        {
            ShopRepository shopRepository = new ShopRepository();
            shopRepository.accessToken = "123456";
            shopRepository.Baseurl = "https://localhost:44322/";
            productsController t = new productsController(shopRepository);
            ViewResult r = t.Index() as ViewResult;
            Assert.AreEqual("Index", r.ViewName);
        }
        [TestMethod]
        public void TestViewNagative()
        {
            ShopRepository shopRepository = new ShopRepository();
            product prod = new product();
            prod.Name = "Test";
            prod.Description = "Test";
            prod.Price = 12000;
            shopRepository.accessToken = "1234567";
            shopRepository.Baseurl = "https://localhost:44322/";
            productsController t = new productsController(shopRepository);
            ViewResult r = t.Create(prod) as ViewResult;
            // After successfull creation redirect to Index view
            string v = Convert.ToString(r.ViewBag.Message);
            Assert.AreEqual("Unauthorized", v);
        }
    }
}
