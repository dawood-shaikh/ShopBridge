﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ShopbridgeAPI.Models
{
    public class Productmetadata
    {
        [Key]
        public int ProdId { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string Description { get; set; }
        [Required]
        [DisplayFormat(DataFormatString = "{0:C2}")]
        [Range(0.01, 100000, ErrorMessage = "Price is required between .01 and $100,000.")]
        [DataType(DataType.Currency,ErrorMessage ="Price should be in positive currency")]
        public decimal? Price { get; set; }
        public string imagepath { get; set; }
        public Nullable<System.DateTime> DOE { get; set; }
        public Nullable<bool> Active { get; set; }

    }

    [MetadataType(typeof(Productmetadata))]
    public partial class tblproduct
    {

    }
}