﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShopbridgeAPI.Models
{
    public enum ReponseStatus
    {
        Success,
        Failure
    }
    public class ResponseBase
    {
        private List<string> _validation = null;
        public ResponseBase()
        {
            _validation = new List<string>();
        }
        public List<string> validation { get { return _validation; } set { _validation = value; } }
        public void AddValidation(string msg)
        {
            _validation.Add(msg);
            this._status = "Failure";
        }
        private string _status;
        public string Status
        {
            get { return _status; }
            set { _status = value; }
        }
        public string Exception { get; set; }
    }
}