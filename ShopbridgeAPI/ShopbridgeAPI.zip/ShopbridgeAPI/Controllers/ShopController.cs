﻿using ShopbridgeAPI.Filter;
using ShopbridgeAPI.Models;
using ShopbridgeAPI.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.ModelBinding;

namespace ShopbridgeAPI.Controllers
{
    public class ShopController : ApiController
    {
        private readonly IShopRepository _shopRepository = null;
        private readonly ResponseBase _responseBase = null;

        public ShopController(IShopRepository shopRepository, ResponseBase responseBase)
        {
            _shopRepository = shopRepository;
            _responseBase = responseBase;
        }

        // GET api/<controller>
        [HttpGet]
        [CustomAuthenticationFilter]
        public List<tblproduct> Getlistofproduct()
        {
            return _shopRepository.getallproduct();
        }
        // GET api/<controller>/5
        [CustomAuthenticationFilter]
        public tblproduct Get(int id)
        {
            return _shopRepository.getproductbyid(id);
        }

        // POST api/<controller>
        [CustomAuthenticationFilter]
        public ResponseBase Post([FromBody] tblproduct prod)
        {
            try
            {
                if(!ModelState.IsValid)
                {
                    _responseBase.validation = geterrorlist(ModelState.Values);
                    _responseBase.Status = "Failure";
                    return _responseBase;
                }
                _shopRepository.Addproduct(prod);
                _responseBase.Status = "Success";
            }
            catch(Exception ex)
            {
                _responseBase.Exception = ex.Message;
                _responseBase.Status = "Failure";
            }
            return _responseBase;
        }

        // PUT api/<controller>/5
        [CustomAuthenticationFilter]
        public ResponseBase Put([FromBody] tblproduct prod)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    _responseBase.validation = geterrorlist(ModelState.Values);
                    _responseBase.Status = "Failure";
                    return _responseBase;
                }
                _shopRepository.Updateproduct(prod);
                _responseBase.Status = "Success";
            }
            catch (Exception ex)
            {
                _responseBase.Exception = ex.Message;
                _responseBase.Status = "Failure";
            }
            return _responseBase;
            
        }

        // DELETE api/<controller>/5
        [CustomAuthenticationFilter]
        public object Delete(int id)
        {
            try
            {
                _shopRepository.Deleteproduct(id);
                _responseBase.Status = "Success";
            }
            catch (Exception ex)
            {
                _responseBase.Exception = ex.Message;
                _responseBase.Status = "Failure";
            }
            return _responseBase;           
        }

        private List<string> geterrorlist(ICollection<ModelState> modelErrors)
        {
            List<string> liststring = new List<string>();
            var collection = modelErrors.Select(x => x.Errors).ToList();
            foreach (ModelErrorCollection modelErrors1 in collection)
            {
                foreach (var item in modelErrors1)
                {
                    liststring.Add(item.ErrorMessage);
                }
            }
            return liststring;
        }
    }
}