﻿using ShopbridgeAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopbridgeAPI.Repository
{
    public interface IShopRepository : IDisposable
    {
        List<tblproduct> getallproduct();
        tblproduct getproductbyid(int Id);
        void Updateproduct(tblproduct prod);
        void Addproduct(tblproduct prod);
        void Deleteproduct(int Id);

    }
}
